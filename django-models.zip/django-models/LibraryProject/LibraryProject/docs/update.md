book.title = "Nineteen Eighty-Four"
book.save()
print(f"Updated Title: {book.title}")


<!-- output -->
Updated Title: Nineteen Eighty-Four
